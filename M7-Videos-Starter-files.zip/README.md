# Practice Javascript Coding

Notice how we load other files into our code. eg mystyles.css and ball.js. Sometimes we do this to "hide" complexity. Here we are hiding the complexity of dealing with the browser memory by putting that in ball.js.

## Projectile.html

This allows you to create balls that move under gravity. They will bounce off the walls.
Understand how to create a ball at a specific location. Also to give it a velocity that varies under gravity.
Understand how arrays are used to store lots of balls.

## Randomwalk.html

This explores how molecule move randomly.
We investigate a "sneeze"
Can you add gravity so the virus particles drop to the ground?

## Randomwalk2.html

Here we add tracking of the particles. How do we do this? It seems "wasteful" to create lots of copies of the particles. However, in the browser its the only way.

## string.html
